from django.db import models

MALE, FEMALE = range(2)
GENDER = (
    (MALE, 'MALE'),
    (FEMALE, 'FEMALE')
)


CHINESE, SPANISH, ENGLISH, FRENCH, HINDI, ARABIC, RUSSIAN = range(7)
KASPANISH,RAJENGLISH,AB,CD = range(4)

LANGUAGES = (
    (CHINESE, 'CHINESE'),
    (SPANISH, 'SPANISH'),
    (ENGLISH, 'ENGLISH'),
    (FRENCH, 'FRENCH'),
    (HINDI, 'HINDI'),
    (ARABIC, 'ARABIC'),
    (RUSSIAN, 'RUSSIAN'),
)

STATE = (
    (KASPANISH, 'KASPANISH'),
    (RAJENGLISH, 'RAJENGLISH'),
    (AB, 'AB'),
    (CD, 'CD'),
   
)

class Student(models.Model):
    full_name = models.CharField('Full Name', max_length=50)
    gender = models.PositiveSmallIntegerField('Gender', choices=GENDER, default=MALE)
    location = models.PositiveSmallIntegerField('State',choices=STATE,default=CD)
    language = models.PositiveSmallIntegerField('Language', choices=LANGUAGES, default=ENGLISH)
    grades = models.CharField('Grades', max_length=2)

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = ('Student')



class Attendence(models.Model):
    
    Student = models.ForeignKey('Student', on_delete=models.CASCADE)

    subject = models.CharField('Full Name', max_length=50)
    gender1 = models.PositiveSmallIntegerField('Gender', choices=GENDER, default=MALE)
    location1 = models.PositiveSmallIntegerField('State',choices=STATE,default=CD)
    language1 = models.PositiveSmallIntegerField('Language', choices=LANGUAGES, default=ENGLISH)
    
    def __str__(self):
        return self.subject    

    class Meta:
        verbose_name = ('Attendence')
